//Request
function request(){

	var mailformat = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	var special_pattern = /[`~!@#$%^&*|\\\'\";:\/?^=^+_()<>]/gi;
	var num_reg = new RegExp('^[0-9]+$');
	
	var company = document.getElementById('company').value;
	var part = document.getElementById('part').value;	
	var name = document.getElementById('name').value;
	var grade = document.getElementById('grade').value;
	var phone = document.getElementById('phone').value;
	var email = document.getElementById('email').value;
	var content = document.getElementById('content').value;
	
	var consult_chx = document.getElementById('consult_chx').checked;
	var demo_chx = document.getElementById('demo_chx').checked;
	var partner_chx = document.getElementById('partner_chx').checked;
	var individual_chx = document.getElementById('individual_chx').checked;
	var news_chx = document.getElementById('news_chx').checked;
	
//	var service_policy_checkbox = document.getElementById('service_policy_checkbox');
//	var user_info_checkbox = document.getElementById('user_info_checkbox');
//	var isService_Checked = service_policy_checkbox.checked;
//	var isUser_Checked = user_info_checkbox.checked
	
	if(company == '' || part == '' || name == '' || grade == '' || phone == '' || email == ''|| content == ''){		
		alert('빈 칸을 채워주세요.');
		return false;
	}
	if(!individual_chx || !news_chx){
		alert('이용 약관에 동의해주세요.');
		return false;
	}
	if(!email.match(mailformat)){
		alert("Email을 확인해주세요.");
		return false;  
	}
	if(content == '문의 및 요청 내용을 입력 해주시면 담당자 확인 즉시 연락 드리겠습니다.'){
		alert('문의사항을 확인해 주세요.');
		return false;
	}

	if( special_pattern.test(name) == true ){
	    alert('특수문자는 사용할 수 없습니다.');
	    return false;
	}
	if( phone == '' ){
	    alert('연락처를 입력해주세요.');
	    return false;
	}
	if( phone.length > 11 || phone.length < 7 || !phone.match(num_reg) ){
		alert('연락처를 확인해주세요.');
	    return false;
	}
	
// php에서 체크
//	dataString ='captcha='+securekey; 
//	var captcha_flag = "false";
//	$.ajax({
//        type        : "POST",
//        url         : "/user/check_captcha",
//        data        : dataString,  
//        dataType    : "text",
//        encode      : true,
//        async       : false,
//
//	    success : function(data){
//	    	
//	    	captcha_flag = data;
//	    }
//    });
//    if(captcha_flag == 'false'){
//		alert('보안문자를 확인해주세요');
//		return false;
//	}

	return true;
}



$(function() {
	$( "#ajax_remake_captcha" ).button().on( "click", function() {
	
		id = "a";
		var dataString = 'post_id='+ id;
		
		$.ajax({
	        type        : "POST",
	        url         : "/Support/remake_captcha",
	        data        : dataString,  
	        dataType    : "json",
	        encode      : true,
	
		    success : function(data){		    	
		    	if(data.status == "success"){
		    		
		    	$('#captcha_image').html(data.data);
		    		
		    	}
		    },
		    error : function(results){
	            alert("fail");
		    }   
	    })
	});
	
	
	$( ".case_acc" ).button().on( "click", function() {

		$('#example1').show();

	});
	
});
	
	
		




$(document).ready(function(){
	var isFist = false;
	
    $(".flip").click(function(){
        $(this).next().slideToggle("slow");
        
        if(isFist == false){
	        var src = ($(this).find('.penel_icon').attr("src") === "/assets/images/icon_down.png") ? "/assets/images/icon_up.png" : "/assets/images/icon_down.png";
	        $(this).find('.penel_icon').attr("src", src);
	        isFirst = true;
        } else {
        	var src = ($(this).find('.penel_icon').attr("src") === "/assets/images/icon_up.png") ? "/assets/images/icon_down.png" : "/assets/images/icon_up.png";
	        $(this).find('.penel_icon').attr("src", src); 	
        }
    });


});


