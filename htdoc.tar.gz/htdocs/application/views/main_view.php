<link rel="stylesheet" href="/assets/css/main.css" type="text/css">
    
    <div id="head_img">
    	<div class="head_img_inner">
			<div class="head_text">
				
                <p class="sub_text">JFLUKE</p>
                <p class="sub_text">See investemnt How much you got benefit.</p>
				<p class="sub_text">Compare the price in the different exchanges.</p>
				<p class="sub_text">Sell Cryptocurrencies at a high price.</p>

			</div>
        </div>   
    </div>

  	<?php 
			//coinone
 			$coinone_btc_currency = strtoupper($coinone['btc_currency']);
			$coinone_btc_last = number_format(round($coinone['btc_last']));

			$coinone_eth_currency = strtoupper($coinone['eth_currency']);
			$coinone_eth_last = number_format(round($coinone['eth_last']));

			$coinone_xrp_currency = strtoupper($coinone['xrp_currency']);
			$coinone_xrp_last = number_format(round($coinone['xrp_last']));

			$coinone_pib_currency = strtoupper($coinone['pib_currency']);
			$coinone_pib_last = number_format($coinone['pib_last']);

			$coinone_bch_currency = strtoupper($coinone['bch_currency']);
			$coinone_bch_last = number_format(round($coinone['bch_last']));

			$coinone_ltc_currency = strtoupper($coinone['ltc_currency']);
			$coinone_ltc_last = number_format(round($coinone['ltc_last']));
		
			//coinfield
 			$coinfield_btc_currency = strtoupper($coinfield['btc_currency']);
			$coinfield_btc_last = number_format(round($coinfield['btc_last'] * $exchange['cad_krw']));

			$coinfield_eth_currency = strtoupper($coinfield['eth_currency']);
			$coinfield_eth_last = number_format(round($coinfield['eth_last'] * $exchange['cad_krw']));

			$coinfield_xrp_currency = strtoupper($coinfield['xrp_currency']);
			$coinfield_xrp_last = number_format(round($coinfield['xrp_last'] * $exchange['cad_krw']));

			$coinfield_ltc_currency = strtoupper($coinfield['ltc_currency']);
			$coinfield_ltc_last = number_format(round($coinfield['ltc_last'] * $exchange['cad_krw']));

			$coinfield_bch_currency = strtoupper($coinfield['bch_currency']);
			$coinfield_bch_last = number_format(round($coinfield['bch_last'] * $exchange['cad_krw']));

			$coinfield_dash_currency = strtoupper($coinfield['dash_currency']);
			$coinfield_dash_last = number_format(round($coinfield['dash_last'] * $exchange['cad_krw']));

			//HUOBI
 			$huobi_btc_currency = strtoupper($huobi['btc_currency']);
			$huobi_btc_last = number_format(round($huobi['btc_last'] * $exchange['usd_krw']));

			$huobi_eth_currency = strtoupper($huobi['eth_currency']);
			$huobi_eth_last = number_format(round($huobi['eth_last'] * $exchange['usd_krw']));

			$huobi_xrp_currency = strtoupper($huobi['xrp_currency']);
			$huobi_xrp_last = number_format(round($huobi['xrp_last'] * $exchange['usd_krw']));

			$huobi_bch_currency = strtoupper($huobi['bch_currency']);
			$huobi_bch_last = number_format(round($huobi['bch_last'] * $exchange['usd_krw']));
			
			$huobi_dash_currency = strtoupper($huobi['dash_currency']);
			$huobi_dash_last = number_format(round($huobi['dash_last'] * $exchange['usd_krw']));

			//BITHUMB
 			$bithumb_btc_currency = strtoupper($bithumb['btc_currency']);
			$bithumb_btc_last = number_format(round($bithumb['btc_last']));

			$bithumb_eth_currency = strtoupper($bithumb['eth_currency']);
			$bithumb_eth_last = number_format(round($bithumb['eth_last']));

			$bithumb_xrp_currency = strtoupper($bithumb['xrp_currency']);
			$bithumb_xrp_last = number_format(round($bithumb['xrp_last']));

  	?>
<div id="container3">
    	<div class="container3_inner" style="width:1200px;">
   
    <div style="display:inline;width:250px; float:left; margin-right:10px;">
    <table id="coinone_tbl" width="300" border="0" cellspacing="1" cellpadding="0" >
			<tr>
                
                <td align="center" bgcolor="#fbfbfb" class="bk01" colspan="2">COINONE</td>
				
			</tr>
			<tr>
				<td height="30" width="30" align="center" bgcolor="#fbfbfb" class="bk01">Currency</td>
                <td height="30" width="30" align="center" bgcolor="#fbfbfb" class="gr01">Price</td>
			</tr>

			<tr>
                <td height="30" width="30" align="center" bgcolor="#FFFFFF" class="gr01"><?=$coinone_btc_currency?></td>
                <td height="30" width="30" align="center" bgcolor="#FFFFFF" class="gr01"><?=$coinone_btc_last?></td>
			</tr>

			<tr>
				<td height="30" width="30" align="center" bgcolor="#FFFFFF" class="gr01"><?=$coinone_eth_currency?></td>
                <td height="30" width="30" align="center" bgcolor="#FFFFFF" class="gr01"><?=$coinone_eth_last?></td>
			</tr>

			<tr>
				<td height="30" width="30" align="center" bgcolor="#FFFFFF" class="gr01"><?=$coinone_xrp_currency?></td>
                <td height="30" width="30" align="center" bgcolor="#FFFFFF" class="gr01"><?=$coinone_xrp_last?></td>
			</tr>

			<tr>
				<td height="30" width="30" align="center" bgcolor="#FFFFFF" class="gr01"><?=$coinone_ltc_currency?></td>
                <td height="30" width="30" align="center" bgcolor="#FFFFFF" class="gr01"><?=$coinone_ltc_last?></td>
			</tr>

			<tr>
				<td height="30" width="30" align="center" bgcolor="#FFFFFF" class="gr01"><?=$coinone_bch_currency?></td>
                <td height="30" width="30" align="center" bgcolor="#FFFFFF" class="gr01"><?=$coinone_bch_last?></td>
			</tr>

			<tr>
				<td height="30" width="30" align="center" bgcolor="#FFFFFF" class="gr01"><?=$coinone_pib_currency?></td>
                <td height="30" width="30" align="center" bgcolor="#FFFFFF" class="gr01"><?=$coinone_pib_last?></td>
			</tr>

			</table>
	 </div>


	 <div style="display:inline;width:250px;float:left; margin-right:10px;">
    <table id="coinfield_tbl" width="300" border="0" cellspacing="1" cellpadding="0" >

			<tr>
                <td align="center" bgcolor="#fbfbfb" class="bk01" colspan="2">COINFIELD</td>
			</tr>

			<tr>
				<td width="30" height="30" width="30" align="center" bgcolor="#fbfbfb" class="bk01">Currency</td>
                <td height="30" width="30"  align="center" bgcolor="#fbfbfb" class="bk01">Price</td>
			</tr>

			<tr>
				<td height="30" width="30" align="center" bgcolor="#FFFFFF" class="gr01"><?=$coinfield_btc_currency?></td>
                <td height="30" width="30" align="center" bgcolor="#FFFFFF" class="gr01"><?=$coinfield_btc_last?></td>
			</tr>


			<tr>
				<td height="30" width="30" align="center" bgcolor="#FFFFFF" class="gr01"><?=$coinfield_eth_currency?></td>
                <td height="30" width="30" align="center" bgcolor="#FFFFFF" class="gr01"><?=$coinfield_eth_last?></td>
			</tr>

			<tr>
				<td height="30" width="30" align="center" bgcolor="#FFFFFF" class="gr01"><?=$coinfield_xrp_currency?></td>
                <td height="30" width="30" align="center" bgcolor="#FFFFFF" class="gr01"><?=$coinfield_xrp_last?></td>
			</tr>

			<tr>
				<td height="30" width="30" align="center" bgcolor="#FFFFFF" class="gr01"><?=$coinfield_ltc_currency?></td>
                <td height="30" width="30" align="center" bgcolor="#FFFFFF" class="gr01"><?=$coinfield_ltc_last?></td>
			</tr>

			<tr>
				 <td height="30" width="30" align="center" bgcolor="#FFFFFF" class="gr01"><?=$coinfield_bch_currency?></td>
                 <td height="30" width="30" align="center" bgcolor="#FFFFFF" class="gr01"><?=$coinfield_bch_last?></td>
			</tr>

			<tr>
				<td height="30" width="30" align="center" bgcolor="#FFFFFF" class="gr01"><?=$coinfield_dash_currency?></td>
                <td align="center" bgcolor="#FFFFFF" class="gr01"><?=$coinfield_dash_last?></td>
			</tr>
	</table>
     </div> 

			
	 <div style="display:inline;width:250px;float:left; margin-right:10px;">
    <table id="huobi_tbl" width="300" border="0" cellspacing="1" cellpadding="0" >		

			<tr>
                <td align="center" bgcolor="#fbfbfb" class="bk01" colspan="2">HUOBI</td>
			</tr>
				<td height="30" width="30" align="center" bgcolor="#fbfbfb" class="bk01">Currency</td>
                <td height="30" width="30" align="center" bgcolor="#fbfbfb" class="bk01">Price</td>
			<tr>

			</tr>
				<td height="30" width="30" align="center" bgcolor="#FFFFFF" class="gr01"><?=$huobi_btc_currency?></td>
                <td height="30" width="30" align="center" bgcolor="#FFFFFF" class="gr01"><?=$huobi_btc_last?></td>
			<tr>
				<td height="30" width="30" align="center" bgcolor="#FFFFFF" class="gr01"><?=$huobi_eth_currency?></td>
                <td height="30" width="30" align="center" bgcolor="#FFFFFF" class="gr01"><?=$huobi_eth_last?></td>
			</tr>

			<tr>
				<td height="30" width="30" align="center" bgcolor="#FFFFFF" class="gr01"><?=$huobi_xrp_currency?></td>
                <td height="30" width="30" align="center" bgcolor="#FFFFFF" class="gr01"><?=$huobi_xrp_last?></td>
			</tr>

			<tr>
				<td height="30" width="30" align="center" bgcolor="#FFFFFF" class="gr01"><?=$huobi_bch_currency?></td>
                <td height="30" width="30" align="center" bgcolor="#FFFFFF" class="gr01"><?=$huobi_bch_last?></td>
			</tr>

			<tr>
				<td height="30" width="30" align="center" bgcolor="#FFFFFF" class="gr01"><?=$huobi_dash_currency?></td>
                <td height="30" width="30" align="center" bgcolor="#FFFFFF" class="gr01"><?=$huobi_dash_last?></td>
			</tr>
	</table>
	 </div> 

    <div style="display:inline;width:250px;float:left;">
    <table id="bithumb_tbl" width="300" border="0" cellspacing="1" cellpadding="0" >		

			<tr>
                <td align="center" bgcolor="#fbfbfb" class="bk01" colspan="2">BITHUMB</td>
			</tr>
				<td height="30" width="30"  width="30" align="center" bgcolor="#fbfbfb" class="bk01">Currency</td>
                <td height="30" width="30"  align="center" bgcolor="#fbfbfb" class="bk01">Price</td>
			<tr>
				<td height="30" width="30" align="center" bgcolor="#FFFFFF" class="gr01"><?=$bithumb_btc_currency?></td>
                <td height="30" width="30" align="center" bgcolor="#FFFFFF" class="gr01"><?=$bithumb_btc_last?></td>
			</tr>

			<tr>
				<td height="30" width="30" align="center" bgcolor="#FFFFFF" class="gr01"><?=$bithumb_eth_currency?></td>
                <td height="30" width="30" align="center" bgcolor="#FFFFFF" class="gr01"><?=$bithumb_eth_last?></td>
			</tr>

			<tr>
				<td height="30" width="30" align="center" bgcolor="#FFFFFF" class="gr01"><?=$bithumb_xrp_currency?></td>
                <td height="30" width="30" align="center" bgcolor="#FFFFFF" class="gr01"><?=$bithumb_xrp_last?></td>
			</tr>


	</table>
     </div>

	</div>
 </div>


<?php 

//$btc_max = max(<?=$coinone_btc_currency?>, <?=$coinfield_btc_currency?>, <?=$huobi_btc_currency?>, <?=$bithumb_btc_currency?>);

?>
 <div id="container3">
    	<div class="container3_inner" style="width:1200px;">

		<div style="display:inline;width:250px;float:left;">
			<table id="compare_btc_tbl" width="300" border="0" cellspacing="1" cellpadding="0" >		

					<tr>
						<td align="center" bgcolor="#fbfbfb" class="bk01" colspan="2">BTC</td>
					</tr>
						<td height="30" width="30"  width="30" align="center" bgcolor="#fbfbfb" class="bk01">Price</td>
						<td height="30" width="30"  align="center" bgcolor="#fbfbfb" class="bk01">+/-(%)</td>
					<tr>
						<td height="30" width="30" align="center" bgcolor="#FFFFFF" class="gr01"><?=$btc_max?></td>
						<td height="30" width="30" align="center" bgcolor="#FFFFFF" class="gr01"><?=$bithumb_btc_last?></td>
					</tr>
, 
					<tr>
						<td height="30" width="30" align="center" bgcolor="#FFFFFF" class="gr01"><?=$bithumb_eth_currency?></td>
						<td height="30" width="30" align="center" bgcolor="#FFFFFF" class="gr01"><?=$bithumb_eth_last?></td>
					</tr>

					<tr>
						<td height="30" width="30" align="center" bgcolor="#FFFFFF" class="gr01"><?=$bithumb_xrp_currency?></td>
						<td height="30" width="30" align="center" bgcolor="#FFFFFF" class="gr01"><?=$bithumb_xrp_last?></td>
					</tr>


			</table>
			 </div>
		</div>
 </div>
<!--font-weight: 500;-->
	
     <div id="container4">
    	<div class="container4_inner">
            <div class="title">����Ͻ� ������� ������ ������ ȿ�������� ��ȭ�ϴ� �ְ��� ����!</div>
            <div class="sub_text">���������� BEYOND SECURITY(���� ��ť��Ƽ)�� AVDS�� �ͻ粲��<br>
            �ż��ϰ� �������� ���� �۾� ����� ���� ��ȭ�� �����ϵ���<br>
            ���� �帮�ڽ��ϴ�.</div>
            <div class="sub_text2">�� ���������� �۷ι� ���� ��� BEYOND SECURITY(���� ��ť��Ƽ)���� AVDS �ѱ� ���� �Դϴ�.</div>
            <div class="inquiry"><a href="/Support"><img src="/assets/images/bt_inquiry.png" alt="" align="middle"/></a></div>
    	</div>
    </div>