<link rel="stylesheet" href="/assets/css/function.css" type="text/css">    
    <div id="head_img">
    	<div class="head_img_inner">
			<div class="head_text">
				<p class="maintitle">AVDS</p>
                <p class="sub_text">가시성 (Visibility), 무결성 (Integrity), 방어 (Protection)<br>
                최적의 보안 파트너
                </p>
			</div>
        </div>   
    </div>
    
    <div id="container1">
    	<div class="container1_inner">
            <div class="s_title">AVDS 주요 기능</div>
            <div class="text1">네트워크 취약점 진단과 웹 애플리케이션 취약점 진단을 위해 별도의 솔루션을 구매하는 것은 불편합니다.<br>
            AVDS (Automated Vulnerability Detection System)는 네트워크와 웹 보안 취약점을 동시에 지원하는 <span class="text1_p">단일 솔루션</span> 입니다.<br>
            관리자는 효과적으로 보안 취약점을 파악해 사전에 위험 요소를 차단하여 보안사고 대응, 복구 시간 및 비용 절감을 할 수 있는<br>
            <span class="text1_p">자동 취약점 탐지 시스템</span> 입니다.
            </div>
            <div class="line"></div>
            <div class="point_box">
            	<img class="point_icon" src="/assets/images/function_icon01.png" alt="" align="middle"/>
                <div class="text_box">
                    <p class="text2">포괄적인 보안 취약점 진단 기능</p>
                    <p class="text3">
                    네트워크 시스템, 웹 어플리케이션, 데이터베이스, 운영 시스템, 개발언어, OSI 7 계층까지<br>
                    광범위한 보안 취약점 진단 동시 지원 가능
                    </p>
				</div>
                <div class="line_s"></div>
			</div>
            <div class="point_box">
            	<img class="point_icon" src="/assets/images/function_icon02.png" alt="" align="middle"/>
                <div class="text_box">
                    <p class="text2">효율적인 티켓팅 시스템 및 보안 취약점 스케쥴링 기능</p>
                    <p class="text3">
                    투명하고 명확한 현황 파알부터 리포팅까지 체계적인 이력 관리 기능<br>
                    보안 관리자에게 이력 변경 실시간 알람 시스템 기능 지원<br>
                    자동화된 스캐닝 프로세스 및 스캐닝 일정 선택 가능
                    </p>
				</div>
                <div class="line_s"></div>
			</div>
            <div class="point_box">
            	<img class="point_icon" src="/assets/images/function_icon03.png" alt="" align="middle"/>
                <div class="text_box">
                    <p class="text2">다양하고 유용한 리포팅 기능</p>
                    <p class="text3">
                    다양한 리포트 형식 (HTML, PDF, XML, CSV) 제공<br>
                    그룹, 자산별 보안 취약점 점수 및 리포팅 기능 제공<br>
                    개선사항 비교 검색 기능 지원
                    </p>
				</div>
                <div class="line_s"></div>
			</div>
            <div class="point_box">
            	<img class="point_icon" src="/assets/images/function_icon04.png" alt="" align="middle"/>
                <div class="text_box">
                    <p class="text2">사용자 정책에 따른 자산 테이블 및 정책 설정 기능</p>
                    <p class="text3">
                    AVDS 정책 기능을 통한 사용자 취약점 정책 지침을 기반으로 스캔 결과 표시<br>
                    신규 정책 생성 기능 지원
                    </p>
				</div>
			</div>
    	</div>
    </div>
    