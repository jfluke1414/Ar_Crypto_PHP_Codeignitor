<link rel="stylesheet" href="/assets/css/email.css" type="text/css">
    <div id="head_img">
    	<div class="head_img_inner">
			<div class="head_text">
				<p class="maintitle">이메일무단수집거부</p>
			</div>
        </div>   
    </div>
    
    <div id="container1">
    	<div class="container1_inner">
            <div class="s_title">이메일무단수집거부</div>
            <div class="text1">
				본 웹사이트에 게시된 이메일 주소가 전자우편 수집 프로그램이나 그 밖의 기술적 장치를 이용하여 무단으로 수집되는 것을 거부하며, <br>
                이를 위반시 정보통신망법에 의해 형사 처벌됨을 유념하시기 바랍니다.
            </div>
    	</div>
    </div>
    