<div id="head_img">
    	<div class="head_img_inner">
			<div class="head_text">
				<p><img src="/assets/images/bi2.png" alt="" align="middle"/></p>
                <p class="sub_text">Please login<br>
                <p class="bt_company_more"><a href="/Intro"></a></p>
			</div>
        </div>   
    </div>
    
<form method="post" action="/Manage/login_end" name="login_form" id="login_form">    
    <div id="container2">
    	<div class="container2_inner">        	
            <div>
	            <table width="500" style="margin-right: auto; margin-left: auto;" border="1" cellspacing="0" cellpadding="0" bordercolor="#e4e4e4">
					<tr>
						<td height="60" class="text1" width="100"><span class="text1_r">*</span> ID</td>
						<td class="text2" width="100"><input style="width:350px;height:40px;" name="userid" type="text" class="input1" id="userid" /></td>
					</tr>
					
					<tr>
						<td align="center" height="60" class="text1" width="100"><span class="text1_r">*</span> PW</td>
						<td class="text2" width="100" ><input style="width:350px;height:40px;" name="userpw" type="password" class="input1" id="userpw" /></td>
					</tr>
					
					<table style="margin-right: auto; margin-left: auto;">
					</br>
					<tr>
						<td>
						<div class="bt_ok"><input TYPE="IMAGE" src="/assets/images/bt_ok.png" width="96" height="49" align="center" name="submit" value="submit"></div>
						</td>
					</tr>
					</table>
	            </table>
            </div>
			</div>
		</div>
    </div>
    </form>

