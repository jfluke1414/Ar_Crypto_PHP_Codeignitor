<!--<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="www.w3.org/1999/xhtml/index.html">-->

<!doctype html>
<html>
<head>

<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<meta http-equiv="content-type" content="application/json;charset=UTF-8" />

<meta name="viewport" content="width=device-width, initial-scale=0.0"/>
<!--<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=yes">
<meta http-equiv="X-UA-Compatible" content="IE=edge" />-->

<!--<link rel="shortcut icon" href="http://218.234.20.166/favicon.png" type="image/x-icon"/>
<link rel="icon" href="http://218.234.20.166/favicon.png" type="image/x-icon" />-->


<script type="text/javascript" src="/assets/js/jquery-1.11.1.min.js"></script>
<script type="text/javascript" src="/assets/js/jquery-ui.min.js"></script>
<script type="text/javascript" src="/assets/js/pdfobject.js"></script>
<script type="text/javascript" src="/assets/js/avds.js"></script>
<script type="text/javascript" src="/assets/js/rolVideo.min.js"></script>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">

<title>JFLUKE</title>
</head>



<body>
<div id="wrap">
	<div class="sub_nav_all">
		<div class="sub_nav">
			
			<div>

				<ul>
					<li><a href="/index.php/Intro">Investment</a></li>
					<li><a href="/index.php/Functions">Wating1</a></li>
                    <li><a href="/index.php/Cases">Wating2</a></li>
                    <li><a href="/index.php/Notice/notice_1">Waiting3</a></li>
					<li><a href="/index.php/Support">Wating4</a></li>
					<li><a href="/index.php/Company">Wating5</a></li>
					
				</ul>

			</div>
		</div>
    </div>
    
    
 