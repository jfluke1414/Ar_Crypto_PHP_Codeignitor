    
    <div id="footer">
    	<div class="footer_menu">
        
        </div>
    	<div class="footertext">
        JFLUKE COINCHECK INVESTMENT | jfluke1414@gmail.com<BR>
        COPYRIGHT 2019 JFLUKE. ALL RIGHTS RESERVED
        </div>
    </div>
</div>
</body>
</html>
