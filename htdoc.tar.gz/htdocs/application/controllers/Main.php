<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Main extends Crypto_Controller {

	public function __construct()
	{
		parent::__construct();		
	}
	
	public function index()
	{		
		$this->_header(); 
		
		$data = array();
		//$data['coinone'] = $this->get_coinone_info(); 
		//$data['coinfield'] = $this->get_coinfield_info();
		//$data['huobi'] = $this->get_huobi_info();
		//$data['bithumb'] = $this->get_bithumb_info();
		//$data['exchange'] = $this->get_exchange_rate();
		
		$coinone = $this->get_coinone_info();
		
		$this->save_request($coinone);
		//$this->save_request($this->get_coinfield_info());
		//$this->save_request($this->get_huobi_info());
		//$this->save_request($this->get_bithumb_info());
		//$this->save_request($this->get_exchange_rate());
		
		
		//var_dump($data);

    	//$data = array();
    	//$data['coinone'] =  	
	
        $this->load->view('main_view', $data);
		
		$this->_footer();
	}
	
	
	
	public function save_request($data)
	{

		if($data == null){
			$msg = "Please check data. It's probably empty.";
			echo("
			<script>
			alert('$msg');
			history.back();
			</script>
			");
			exit;
		}
		
        $this->load->model('Mains');
		$this->Mains->save_request($data);

	}
	
	
	
	function get_coinone_info()
    {
		
		/*$coindata = array(
		
		'id' => 'coinone',
		'currency' => 'btc',
		'name' => 'hyunjin'
		
		);*/
		
		$coinone_url = 'https://api.coinone.co.kr/ticker/?currency="BTC"';
		
		$curl_handle=curl_init();
		curl_setopt($curl_handle, CURLOPT_URL,$coinone_url);
		curl_setopt($curl_handle, CURLOPT_CONNECTTIMEOUT, 2);
		curl_setopt($curl_handle, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($curl_handle, CURLOPT_USERAGENT, 'Your application name');
		$coinone_data = curl_exec($curl_handle);
		curl_close($curl_handle);

		$data = json_decode($coinone_data);
		
		$btc_arr = $data->btc;
		$eth_arr = $data->eth;
		$xrp_arr = $data->xrp;
		$ltc_arr = $data->ltc;
		$bch_arr = $data->bch;
		$pib_arr = $data->pib;

		$datas = array();
		
		$datas['exchange_name'] = "coinone";
			if($btc_arr->currency == "btc"){
				$datas['btc_currency'] =  $btc_arr->currency;
				$datas['btc_last'] =  $btc_arr->last;
			}
			
			if($eth_arr->currency == "eth"){
				
				$datas['eth_currency'] =  $eth_arr->currency;
				$datas['eth_last'] =  $eth_arr->last;	
			}
			if($xrp_arr->currency == "xrp"){
				$datas['xrp_currency'] =  $xrp_arr->currency;
				$datas['xrp_last'] =  $xrp_arr->last;	
			}
			if($ltc_arr->currency == "ltc"){
				$datas['ltc_currency'] =  $ltc_arr->currency;
				$datas['ltc_last'] =  $ltc_arr->last;	
			}
			if($bch_arr->currency == "bch"){
				$datas['bch_currency'] =  $bch_arr->currency;
				$datas['bch_last'] =  $bch_arr->last;	
			}
			if($pib_arr->currency == "pib"){
				$datas['pib_currency'] =  $pib_arr->currency;
				$datas['pib_last'] =  $pib_arr->last;	
			}
		//var_dump($datas);
		return $datas;			
    }
    
    function get_coinfield_info()
    {
		
		$coinfield = 'https://api.coinfield.com/v1/tickers';
		
		$curl_handle=curl_init();
		curl_setopt($curl_handle, CURLOPT_URL,$coinfield);
		curl_setopt($curl_handle, CURLOPT_CONNECTTIMEOUT, 2);
		curl_setopt($curl_handle, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($curl_handle, CURLOPT_USERAGENT, 'Your application name');
		$query = curl_exec($curl_handle);
		curl_close($curl_handle);

		$data = json_decode($query);
		//var_dump( $data);
		
		$datas = array();

		foreach ($data->markets as $list){
		
			if($list->market == "btccad"){
				$datas['btc_currency'] =  $list->market;
				$datas['btc_last'] =  $list->last;
			}
		
			if($list->market == "ethcad"){
				$datas['eth_currency'] =  $list->market;
				$datas['eth_last'] =  $list->last;
			}
			
			if($list->market == "xrpcad"){
				$datas['xrp_currency'] =  $list->market;
				$datas['xrp_last'] =  $list->last;
			}
			
			if($list->market == "ltccad"){
				$datas['ltc_currency'] =  $list->market;
				$datas['ltc_last'] =  $list->last;
			}
			
			if($list->market == "bchcad"){
				$datas['bch_currency'] =  $list->market;
				$datas['bch_last'] =  $list->last;
			}
			
			if($list->market == "dashcad"){
				$datas['dash_currency'] =  $list->market;
				$datas['dash_last'] =  $list->last;
			}
			
		};
		//var_dump( $datas);
		
		return $datas;			
    }
    
    
    function get_huobi_info()
    {
		
		$huobi = 'https://api.huobi.pro/market/tickers';
		
		$curl_handle=curl_init();
		curl_setopt($curl_handle, CURLOPT_URL,$huobi);
		curl_setopt($curl_handle, CURLOPT_CONNECTTIMEOUT, 2);
		curl_setopt($curl_handle, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($curl_handle, CURLOPT_USERAGENT, 'Your application name');
		$query = curl_exec($curl_handle);
		curl_close($curl_handle);

		$data = json_decode($query);
		//var_dump( $data);
		
		$datas = array();
		
		foreach ($data->data as $list){
		
			if($list->symbol == "btcusdt"){
				$datas['btc_currency'] =  "btc";
				$datas['btc_last'] =  $list->close;
			}
			
			if($list->symbol == "ethusdt"){
				$datas['eth_currency'] =  "eth";
				$datas['eth_last'] =  $list->close;
			}
			
			if($list->symbol == "xrpusdt"){
				$datas['xrp_currency'] =  "xrp";
				$datas['xrp_last'] =  $list->close;
			}
			
			if($list->symbol == "dashusdt"){
				$datas['dash_currency'] =  "dash";
				$datas['dash_last'] =  $list->close;
			}
			
			if($list->symbol == "bchusdt"){
				$datas['bch_currency'] =  "bch";
				$datas['bch_last'] =  $list->close;
			}
		
			
			
		};
		//var_dump( $datas);
		
		return $datas;			
    }
    
    function get_bithumb_info()
    {
		
		$bithumb_all = 'https://api.bithumb.com/public/ticker/all';
		$datas = array();

		$curl_handle=curl_init();
		curl_setopt($curl_handle, CURLOPT_URL,$bithumb_all);
		curl_setopt($curl_handle, CURLOPT_CONNECTTIMEOUT, 2);
		curl_setopt($curl_handle, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($curl_handle, CURLOPT_USERAGENT, 'Your application name');
		$query = curl_exec($curl_handle);
		curl_close($curl_handle);

		$all_data = json_decode($query);
		$list = $all_data->data;
		
		$btc_arr = $list->BTC;
		$eth_arr = $list->ETC;
		$xrp_arr = $list->XRP;

		$datas['btc_currency'] =  "btc";
		$datas['btc_last'] =  $btc_arr->sell_price;	
	
		$datas['eth_currency'] =  "eth";
		$datas['eth_last'] =  $eth_arr->sell_price;	
	
		$datas['xrp_currency'] =  "xrp";
		$datas['xrp_last'] =  $xrp_arr->sell_price;	

		return $datas;			
    }
    
    function get_exchange_rate()
    {
		
		$exchange_url = 'https://free.currconv.com/api/v7/convert?q=cad_krw,usd_krw&compact=ultra&apiKey=1b2360cf16ac589201bc';
		$datas = array();

		$curl_handle=curl_init();
		curl_setopt($curl_handle, CURLOPT_URL,$exchange_url);
		curl_setopt($curl_handle, CURLOPT_CONNECTTIMEOUT, 2);
		curl_setopt($curl_handle, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($curl_handle, CURLOPT_USERAGENT, 'Your application name');
		$exchange_query = curl_exec($curl_handle);
		curl_close($curl_handle);

		$data = json_decode($exchange_query);
		
		$datas['usd_krw'] = $data->USD_KRW;
		$datas['cad_krw'] =  $data->CAD_KRW;

		return $datas;			
    }
    



    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    function get_coinfield_eth_info()
    {
		
		$coinfield_eth = 'https://api.coinfield.com/v1/tickers/ethcad';
		
		$curl_handle=curl_init();
		curl_setopt($curl_handle, CURLOPT_URL,$coinfield_eth);
		curl_setopt($curl_handle, CURLOPT_CONNECTTIMEOUT, 2);
		curl_setopt($curl_handle, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($curl_handle, CURLOPT_USERAGENT, 'Your application name');
		$query = curl_exec($curl_handle);
		curl_close($curl_handle);

		$data = json_decode($query);
		//var_dump( $data);
		
		$datas = array();
		foreach ($data->markets as $list){
			$datas['currency'] =  $list->market;
			$datas['last'] =  $list->last;
		};
		
		return $datas;			
    }

	
}
