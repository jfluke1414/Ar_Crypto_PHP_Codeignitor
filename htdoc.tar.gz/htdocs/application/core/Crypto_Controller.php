<?php
class Crypto_Controller extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->helper('url');
		//$this->load->library('session');
		$this->load->helper('text');
		$this->load->helper('file');
	}


	function _header(){
		$header['title'] = "Crypto";
		$this->load->view("/include/header", $header);
		
	}

	function _manageheader(){
		$header['title'] = "Crypto";
		$this->load->view("/include/manageheader", $header);
		
	}

	
	function _footer(){
		$this->load->view("/include/footer");
	}		

}
