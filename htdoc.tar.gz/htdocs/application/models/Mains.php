<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');

class Mains extends CI_Model {

    function __construct()
    {
        parent::__construct();
		$this->load->database();
    }
    
    function save_request($data)
    {
		
		$this->db->set('currency', $btc_currency);
		$this->db->set('price', $btc_last);
		$this->db->set('exchange_name', $exchange_name);
		$this->db->set('date', 'NOW()', FALSE);
		$this->db->insert('coin_info');
		
		/*$this->db->set('currency', $eth_currency);
		$this->db->set('price', $eth_last);
		$this->db->set('exchange_name', $exchange_name);
		$this->db->set('date', 'NOW()', FALSE);
		$this->db->insert('coin_info');
		
		$this->db->set('currency', $xrp_currency);
		$this->db->set('price', $xrp_last);
		$this->db->set('exchange_name', $exchange_name);
		$this->db->set('date', 'NOW()', FALSE);
		$this->db->insert('coin_info');
		
		$this->db->set('currency', $ltc_currency);
		$this->db->set('price', $ltc_last);
		$this->db->set('exchange_name', $exchange_name);
		$this->db->set('date', 'NOW()', FALSE);
		$this->db->insert('coin_info');
		
		$this->db->set('currency', $bch_currency);
		$this->db->set('price', $bch_last);
		$this->db->set('exchange_name', $exchange_name);
		$this->db->set('date', 'NOW()', FALSE);
		$this->db->insert('coin_info');
		
		$this->db->set('currency', $pib_currency);
		$this->db->set('price', $pib_last);
		$this->db->set('exchange_name', $exchange_name);
		$this->db->set('date', 'NOW()', FALSE);
		$this->db->insert('coin_info');*/
		
    }
    

    function get_release()
    {
    	$this->db->select('id, name, version, content, date(date) as date');
    	$this->db->order_by('id', 'desc');
		$query = $this->db->get('rel_note');
        return $query->result();
    }


	function get_fileInfo()
    {
    	$id = $this->input->get('id');
    	$query = $this->db->where('id', $id);
		$query = $this->db->get('doc_upload');
        return $query->result();
    }


}