
<?php phpinfo(); ?>
